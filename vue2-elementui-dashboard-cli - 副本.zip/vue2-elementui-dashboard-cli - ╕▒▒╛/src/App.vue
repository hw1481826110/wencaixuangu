<template>
  <div id="app">
    <!-- 条件渲染主布局 -->
    <el-container v-if="$route.name !== 'Login'" style="height: 100vh;">
      <!-- 顶部导航 -->
      <el-header style="padding: 0; border-bottom: 1px solid #ebeef5;">
        <el-row>
          <el-col :span="3" style="background-color: #202124; color: white; text-align: center; font-size: 18px;">
            生产管理系统
          </el-col>
          <el-col :span="21">
            <el-row type="flex" justify="end" style="height: 100%;">
              <el-col>
                <el-dropdown trigger="click">
                  <span class="el-dropdown-link" style="margin-right: 20px;">
                    <i class="fa fa-bell-o" style="margin-right: 5px;"></i>
                    <el-badge is-dot :value="4" class="item"></el-badge>
                  </span>
                  <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item>消息通知</el-dropdown-item>
                    <el-dropdown-item>系统通知</el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
              </el-col>
              <el-col>
                <el-dropdown trigger="click">
                  <span class="el-dropdown-link" style="margin-right: 20px;">
                    <i class="fa fa-user-o" style="margin-right: 5px;"></i>
                    管理员
                    <i class="el-icon-arrow-down el-icon--right"></i>
                  </span>
                  <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item>个人信息</el-dropdown-item>
                    <el-dropdown-item>修改密码</el-dropdown-item>
                    <el-dropdown-item divided @click="logout">退出登录</el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </el-header>
      
      <!-- 主体内容 -->
      <el-container>
        <!-- 左侧导航栏 -->
        <el-aside width="200px">
          <el-menu default-active="1" class="el-menu-vertical-demo" router>
            <el-submenu index="1">
              <template #title>
                <i class="fa fa-home"></i>
                <span>首页</span>
              </template>
              <!-- 将index从"1-1"修改为已配置的路由路径 -->
              <el-menu-item index="/dashboard">控制台</el-menu-item>
            </el-submenu>
            <el-submenu index="2">
              <template #title>
                <i class="fa fa-cubes"></i>
                <span>基础资料</span>
              </template>
              <el-menu-item index="2-1">物料管理</el-menu-item>
              <el-menu-item index="2-2">BOM管理</el-menu-item>
              <el-menu-item index="2-3">工艺路线</el-menu-item>
            </el-submenu>
            <el-submenu index="3">
              <template #title>
                <i class="fa fa-archive"></i>
                <span>库存管理</span>
              </template>
              <el-menu-item index="3-1">库存查询</el-menu-item>
              <el-menu-item index="3-2">出入库管理</el-menu-item>
              <el-menu-item index="3-3">库存盘点</el-menu-item>
            </el-submenu>
            <el-submenu index="4">
              <template #title>
                <i class="fa fa-industry"></i>
                <span>生产管理</span>
              </template>
              <el-menu-item index="4-1">生产订单</el-menu-item>
              <el-menu-item index="4-2">生产领料</el-menu-item>
              <el-menu-item index="4-3">生产入库</el-menu-item>
            </el-submenu>
            <el-submenu index="5">
              <template #title>
                <i class="fa fa-truck"></i>
                <span>采购管理</span>
              </template>
              <el-menu-item index="5-1">采购订单</el-menu-item>
              <el-menu-item index="5-2">采购入库</el-menu-item>
            </el-submenu>
            <el-submenu index="6">
              <template #title>
                <i class="fa fa-shopping-cart"></i>
                <span>销售管理</span>
              </template>
              <el-menu-item index="6-1">销售订单</el-menu-item>
              <el-menu-item index="6-2">销售出库</el-menu-item>
            </el-submenu>
            <el-submenu index="7">
              <template #title>
                <i class="fa fa-cog"></i>
                <span>系统设置</span>
              </template>
              <el-menu-item index="7-1">用户管理</el-menu-item>
              <el-menu-item index="7-2">角色管理</el-menu-item>
              <el-menu-item index="7-3">权限管理</el-menu-item>
            </el-submenu>
          </el-menu>
        </el-aside>
        <el-main>
          <router-view />
        </el-main>
      </el-container>
    </el-container>
    <!-- 登录页面独立渲染 -->
    <router-view v-else />
  </div>
</template>

<script>
export default {
  name: 'App',
  methods: {
    logout() {
      this.$confirm('确定要退出登录吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$message({
          type: 'success',
          message: '退出成功'
        });
        // 这里可以添加退出登录的逻辑
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消退出'
        });          
      });
    }
  }
}
</script>

<style>
#app {
  font-family: 'Helvetica Neue', Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  height: 100vh;
}
</style>
