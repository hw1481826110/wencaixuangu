<template>
  <div class="login-container">
    <div class="login-card">
      <div class="login-title">济南绿丰ERP管理后台</div>
      <el-form ref="loginForm" :model="loginForm" :rules="loginRules" class="login-form">
        <el-form-item prop="username">
          <el-input v-model="loginForm.username" placeholder="用户名"></el-input>
        </el-form-item>
        <el-form-item prop="password">
          <el-input type="password" v-model="loginForm.password" placeholder="密码"></el-input>
        </el-form-item>
        <el-form-item class="remember-me">
          <el-checkbox v-model="loginForm.remember">记住账号</el-checkbox>
          <el-link type="primary" class="forgot-password" @click="handleForgotPassword">忘记密码?</el-link>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleLogin" class="login-btn" style="width: 100%">登录</el-button>
        </el-form-item>
      </el-form>
      <div class="login-footer">
        <p>© 2023 likeshop 版权所有</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'LoginPage',
  data() {
    return {
      loginForm: {
        username: '',
        password: '',
        remember: false
      },
      loginRules: {
        username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
        password: [{ required: true, message: '请输入密码', trigger: 'blur' }]
      }
    }
  },
  methods: {
    handleLogin() {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          // 登录成功后跳转到 Dashboard
          this.$router.push('/dashboard')
        }
      })
    },
    handleForgotPassword() {
      this.$message.info('忘记密码功能即将上线')
    }
  }
}
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f5f7fa;
}

.login-card {
  width: 420px;
  padding: 40px;
  background-color: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.login-title {
  text-align: center;
  font-size: 24px;
  font-weight: 700;
  color: #1E88E5;
  margin-bottom: 30px;
}

.remember-me {
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
}

.forgot-password {
  font-size: 13px;
}

.login-btn {
  height: 44px;
  font-size: 15px;
  background: linear-gradient(135deg, #1E88E5 0%, #42A5F5 100%);
  border: none;
}

.login-footer {
  text-align: center;
  margin-top: 30px;
  font-size: 13px;
  color: #B0BEC5;
  letter-spacing: 0.3px;
}
</style>