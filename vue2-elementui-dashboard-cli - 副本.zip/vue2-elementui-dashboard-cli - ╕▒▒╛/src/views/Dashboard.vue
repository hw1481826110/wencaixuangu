<template>
  <div class="dashboard-container">
    <!-- 面包屑导航组件 -->
    <MianbaoXie :items="breadcrumbItems" />
    
    <div style="margin-top: 20px;">
      <!-- 常用菜单组件 -->
      <ChangYongCaidan 
        :menuItems="menuItems" 
        @menu-click="handleMenuClick"
      />
      
      <el-row :gutter="20">
        <el-col :span="12">
          <!-- 待办业务组件 -->
          <DaibanYewu 
            :dataList="todoList" 
            :loading="loading"
          />
        </el-col>
        <el-col :span="12">
          <!-- 任务管理组件 -->
          <RenwuGuanli 
            :dataList="taskList" 
            :loading="loading" 
            @create-task="createNewTask"
          />
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
// 导入组件
import MianbaoXie from '@/components/MianbaoXie';
import ChangYongCaidan from '@/components/ChangYongCaidan';
import DaibanYewu from '@/components/DaibanYewu';
import RenwuGuanli from '@/components/RenwuGuanli';

export default {
  name: 'DashboardView',
  // 注册组件
  components: {
    MianbaoXie,
    ChangYongCaidan,
    DaibanYewu,
    RenwuGuanli
  },
  data() {
    return {
      // 加载状态标志
      loading: false,
      // 面包屑数据
      breadcrumbItems: [
        { label: '首页', path: '/' },
        { label: '控制台', path: '/dashboard' }
      ],
      // 菜单数据
      menuItems: [
        { name: '生产看板', icon: 'fa fa-dashboard', color: '#409EFF', path: '/dashboard' },
        { name: '设备管理', icon: 'fa fa-wrench', color: '#67C23A', path: '/equipment' },
        { name: '生产计划', icon: 'fa fa-calendar', color: '#E6A23C', path: '/planning' },
        { name: '报表中心', icon: 'fa fa-file-text-o', color: '#F56C6C', path: '/reports' },
        { name: '数据分析', icon: 'fa fa-bar-chart', color: '#909399', path: '/analysis' },
        { name: '系统设置', icon: 'fa fa-cog', color: '#303133', path: '/settings' }
      ],
      // 待办业务数据
      todoList: [
        { name: '生产订单已保存', time: '2025-07-05 10:30' },
        { name: '待审核业务（生产订单）', time: '2025-07-05 09:15' }
      ],
      // 任务列表数据
      taskList: []
    }
  },
  mounted() {
    // 页面加载时获取任务数据
    this.loadTaskData();
  },
  methods: {
    /**
     * 处理菜单点击事件，跳转到对应路由
     * @param {Object} item - 菜单项数据
     */
    handleMenuClick(item) {
      this.$router.push(item.path).catch(err => {
        // 捕获路由不存在的错误
        if (err.name !== 'NavigationDuplicated') {
          this.$notify.error({ title: '错误', message: '该功能尚未实现' });
        }
      });
    },
    /**
     * 创建新任务按钮点击事件
     */
    createNewTask() {
      this.$notify.info({ title: '提示', message: '新建任务功能将在后续版本实现' });
    },
    /**
     * 加载任务数据
     */
    loadTaskData() {
      this.loading = true;
      // 模拟API请求
      setTimeout(() => {
        // 实际项目中替换为API调用
        this.taskList = []; // 留空数组保持空状态展示
        this.loading = false;
      }, 800);
    }
  }
}
</script>

<style scoped>
.dashboard-container {
  padding: 20px;
}
</style>