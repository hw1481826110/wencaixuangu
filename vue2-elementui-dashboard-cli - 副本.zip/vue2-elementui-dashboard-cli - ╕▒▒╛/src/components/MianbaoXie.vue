<template>
  <!-- 面包屑导航组件，用于显示页面层级关系 -->
  <el-breadcrumb separator-class="el-icon-arrow-right">
    <el-breadcrumb-item v-for="(item, index) in items" :key="index" :to="item.path">
      {{ item.label }}
    </el-breadcrumb-item>
  </el-breadcrumb>
</template>

<script>
export default {
  name: 'MianbaoXie',
  props: {
    // 面包屑数据，格式为[{label: '首页', path: '/'}]
    items: {
      type: Array,
      required: true,
      default: () => []
    }
  }
}
</script>