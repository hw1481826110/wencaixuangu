<template>
  <!-- 待办业务表格组件 -->
  <el-card shadow="hover" class="task-card">
    <template #header>
      <div class="clearfix">
        <span>{{ title }}</span>
        <el-button style="float: right; padding: 3px 0" type="text">查看全部</el-button>
      </div>
    </template>
    <!-- 待办业务表格，带加载状态 -->
    <el-table
      :data="dataList"
      stripe
      style="width: 100%"
      v-loading="loading"
      element-loading-text="加载中...">
      <el-table-column
        prop="name"
        label="业务名称">
      </el-table-column>
      <el-table-column
        prop="time"
        label="创建时间">
      </el-table-column>
      <el-table-column
        label="操作">
        <template #default>
          <el-button size="mini" type="primary">处理</el-button>
        </template>
      </el-table-column>
    </el-table>
  </el-card>
</template>

<script>
export default {
  name: 'DaibanYewu',
  props: {
    // 表格标题
    title: {
      type: String,
      default: '待办业务'
    },
    // 表格数据
    dataList: {
      type: Array,
      required: true,
      default: () => []
    },
    // 加载状态
    loading: {
      type: Boolean,
      default: false
    }
  }
}
</script>

<style scoped>
.task-card {
  min-height: 200px;
  margin-bottom: 20px;
}
</style>