<template>
  <!-- 常用菜单组件，显示快捷功能入口 -->
  <el-card shadow="hover">
    <template #header>
      <div class="clearfix">
        <span>{{ title }}</span>
      </div>
    </template>
    <el-row>
      <!-- 菜单卡片，点击触发导航事件 -->
      <el-col :span="4" class="menu-card" @click="handleClick(item)" v-for="(item, index) in menuItems" :key="index">
        <i :class="item.icon" :style="{fontSize: '30px', color: item.color}"></i>
        <p>{{ item.name }}</p>
      </el-col>
    </el-row>
  </el-card>
</template>

<script>
export default {
  name: 'ChangYongCaidan',
  props: {
    // 菜单标题
    title: {
      type: String,
      default: '常用菜单'
    },
    // 菜单项数据
    menuItems: {
      type: Array,
      required: true,
      default: () => []
    }
  },
  methods: {
    /**
     * 处理菜单点击事件
     * @param {Object} item - 菜单项数据
     */
    handleClick(item) {
      this.$emit('menu-click', item);
    }
  }
}
</script>

<style scoped>
.menu-card {
  text-align: center;
  cursor: pointer;
  padding: 20px 10px;
  border-radius: 8px;
  transition: all 0.3s ease;
  height: 120px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.menu-card:hover {
  background-color: #f0f7ff;
  transform: translateY(-3px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
}

/* 响应式调整 */
@media (max-width: 768px) {
  .menu-card {
    height: 100px;
  }
}
</style>