import axios from 'axios';
import { Message, Loading } from 'element-ui';
import { getToken } from '@/utils/auth';

// 创建axios实例
const service = axios.create({
  baseURL: process.env.VUE_APP_BASE_API || '', // 从环境变量获取基础URL
  timeout: 5000, // 请求超时时间
  headers: {
    'Content-Type': 'application/json;charset=utf-8'
  }
});

// 加载实例
let loadingInstance;

// 请求拦截器
service.interceptors.request.use(
  config => {
    // 显示加载动画
    loadingInstance = Loading.service({
      lock: true,
      text: '加载中...',
      background: 'rgba(0, 0, 0, 0.7)'
    });

    // 添加token
    const token = getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  error => {
    // 关闭加载动画
    loadingInstance.close();
    Message.error('请求参数错误');
    return Promise.reject(error);
  }
);

// 响应拦截器
service.interceptors.response.use(
  response => {
    // 关闭加载动画
    loadingInstance.close();

    const res = response.data;
    // 自定义状态码处理
    if (res.code !== 200) {
      Message.error(res.message || '操作失败');
      // 未登录或token过期
      if (res.code === 401) {
        // 跳转到登录页
        window.location.href = '/login';
      }
      return Promise.reject(res);
    }
    return res;
  },
  error => {
    // 关闭加载动画
    loadingInstance.close();

    // 网络错误处理
    if (!error.response) {
      Message.error('网络连接异常，请检查网络');
      return Promise.reject(error);
    }

    // HTTP状态码处理
    const status = error.response.status;
    switch (status) {
      case 401:
        Message.error('登录已过期，请重新登录');
        window.location.href = '/login';
        break;
      case 403:
        Message.error('没有操作权限');
        break;
      case 404:
        Message.error('请求资源不存在');
        break;
      case 500:
        Message.error('服务器内部错误');
        break;
      default:
        Message.error(`请求错误: ${status}`);
    }
    return Promise.reject(error);
  }
);

// 封装常用请求方法
export const request = {
  get(url, params = {}) {
    return service.get(url, { params });
  },
  post(url, data = {}) {
    return service.post(url, data);
  },
  put(url, data = {}) {
    return service.put(url, data);
  },
  delete(url, params = {}) {
    return service.delete(url, { params });
  },
  // 上传文件
  upload(url, file, onUploadProgress) {
    const formData = new FormData();
    formData.append('file', file);
    return service.post(url, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress
    });
  }
};

export default service;