
import Vue from 'vue'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import App from './App.vue'
import router from './router'
import { request } from './utils/request' // 引入请求工具
import 'font-awesome/css/font-awesome.min.css';
Vue.use(ElementUI)

// 挂载到Vue原型，全局可用this.$request
Vue.prototype.$request = request;

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
Vue.config.productionTip = false
Vue.use(ElementUI)

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
Vue.config.productionTip = false
Vue.use(ElementUI)

