# Vue2 ElementUI Dashboard 使用文档

## 1. 安装依赖
```bash
# 安装 axios
npm install axios --save
```
## 2. 全局请求工具使用说明
### 2.1 接口调用示例 GET 请求
```
export default {
  methods: {
    async fetchData() {
      try {
        const res = await this.$request.
        get('/api/todoList');
        this.todoList = res.data;
      } catch (error) {
        console.error('获取数据失败', 
        error);
      }
    }
  }
}
//POST 请求

export default {
  methods: {
    async submitForm() {
      try {
        const res = await this.$request.
        post('/api/submit', this.
        formData);
        this.$message.success('提交成功');
      } catch (error) {
        console.error('提交失败', error);
      }
    }
  }
}
```
### 2.2 工具特性
- 自动携带 Token 认证信息
- 统一错误处理机制
- 请求/响应拦截器
- 支持 loading 状态显示
## 3. 注意事项
- 所有 API 请求路径需以 /api 开头
- 接口返回数据格式统一为 { code: 200, data: {}, message: '' }
- 异常情况会自动触发错误提示